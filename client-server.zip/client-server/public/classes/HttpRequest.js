class HttpRequest {

    static get(url, params = {}){

        return HttpRequest.request('GET', url, params);

    }

    static delete(url, params = {}){

        return HttpRequest.request('DELETE', url, params);

    }

    static put(url, params = {}){

        return HttpRequest.request('PUT', url, params);

    }

    static post(url, params = {}){

        return HttpRequest.request('POST', url, params);

    }

    // metodo statico permite que chame ele diretamente sem 
    // precisar cahmar por uma instancia
    static request( method, url, params = {}){
     
        return new Promise((resolve, reject)=>{

            let ajax = new XMLHttpRequest();

            ajax.open(method.toUpperCase(), url);  

            ajax.onerror = event => {

                reject(e);

            }; 
    
            ajax.onload = event => {

                let obj = {};

                try {
    
                    obj = JSON.parse(ajax.responseText);   
        
                } catch(e){
    
                    reject(e);
                    console.error(e);
    
                }

                resolve(obj)
    
            };

            // é importante setar o header informado que é um json que esta sendo enviado
            ajax.setRequestHeader('Content-Type', 'application/json');
    
            // o send do ajax so mando em texto por isso a conversao
            ajax.send(JSON.stringify(params));  

        });

    }

}